$Startup = [Environment]::GetFolderPath('Startup')
Remove-Item -Path "$Startup\init-hider.bat"
Get-CimInstance Win32_Process |
    Where-Object { $_.Name -eq "python.exe" -and $_.CommandLine -like "*besthide.py*" } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
Get-CimInstance Win32_Process |
    Where-Object { $_.Name -eq "python.exe" -and $_.CommandLine -like "*selector.py*" } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
Remove-Item -Path "env" -Recurse
Remove-Item -Path "python" -Recurse

echo "Please delete the rest of the files manually. Thanks for using this."