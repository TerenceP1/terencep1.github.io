import cv2
import os
os.system("echo please press any key to select a camera & pause > nul")
def list_cameras(max_devices=5):
    available = []
    for i in range(max_devices):
        cap = cv2.VideoCapture(i)
        if cap.isOpened():
            available.append(i)
            cap.release()
    return available

def pick_camera():
    cameras = list_cameras()
    if not cameras:
        print("No cameras found")
        return None

    for cam_idx in cameras:
        os.system(f"title Previewing Camera {cam_idx} - Press 's' to select")
        cap = cv2.VideoCapture(cam_idx)
        print(f"Previewing Camera {cam_idx}... Press 's' to select, 'n' for next")
        
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            cv2.imshow(f"Camera {cam_idx} (press n for next camera or s to save the camera)", frame)

            key = cv2.waitKey(1) & 0xFF
            if key == ord('s'):
                cap.release()
                cv2.destroyAllWindows()
                return cam_idx  # User selected this camera
            elif key == ord('n'):
                break  # Move to next camera

        cap.release()
        cv2.destroyAllWindows()

    return None

selected = pick_camera()
while selected is None:
    print(f"Selected camera: {selected}")
    selected = pick_camera()
with open("camId.txt",'w') as f:
    f.write(str(selected))

