from filelock import FileLock, Timeout
import sys
import os

lock = FileLock("mainLock.lock")

try:
    # Try to acquire lock (wait up to 1 second)
    lock.acquire(timeout=1)
    print("Lock acquired. Working...")



except Timeout:
    print("Another hider is running. Exiting...")
    os.system("pause")
    sys.exit(1)
    lock.release()
    print("Lock released.")


import ctypes
import time
import cv2
import numpy as np
import os
import keyboard
keyboard.wait("Ctrl+B")
print("ARMED")
#time.sleep(3)
user32 = ctypes.windll.user32
kernel32 = ctypes.windll.kernel32

# Step 1: Get current foreground window handle
original_hwnd = user32.GetForegroundWindow()

# Optional: get window title
title = ctypes.create_string_buffer(256)
user32.GetWindowTextA(original_hwnd, title, 256)
print("Captured window title:", title.value.decode())

time.sleep(5)
# Step 2: Wait for a while
num=0
with open("camId.txt") as f:
    num=int(f.read())
cap=cv2.VideoCapture(num)
time.sleep(1)
ret, lst = cap.read()
ret, lst = cap.read()
ret, lst = cap.read()
lst=cv2.cvtColor(lst, cv2.COLOR_BGR2GRAY)
time.sleep(0.1)
for i in range(20):
    ret, lst = cap.read()
    if not ret:
        continue
    gray = cv2.cvtColor(lst, cv2.COLOR_BGR2GRAY)
    lst=gray
    if gray.max() > 30:  # frame has actual brightness
        lst = gray
        print(f"Got usable frame on attempt {i}")
        break
    time.sleep(0.1)
while True:
    ret, frame = cap.read()
    frame=cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    print("lst min/max:", lst.min(), lst.max())
    cv2.imshow("window",np.abs(lst.astype(np.int32)-frame.astype(np.int32)).astype(np.uint8))
    cv2.waitKey(16)
    if np.max(np.abs(lst.astype(np.int32)-frame.astype(np.int32)))>150:
                
        # # Step 3: Restore window if minimized
        # SW_RESTORE = 9
        # user32.ShowWindow(original_hwnd, SW_RESTORE)

        # Step 4: Try to bring it back to the front
        fg_thread = user32.GetWindowThreadProcessId(original_hwnd, None)
        this_thread = kernel32.GetCurrentThreadId()

        # 1. Restore the window if minimized

        # 2. Temporarily allow your thread to interact with the foreground one
        user32.AttachThreadInput(this_thread, fg_thread, True)
        VK_MENU = 0x12
        user32.keybd_event(VK_MENU, 0, 0, 0)  # Alt down
        user32.keybd_event(VK_MENU, 0, 2, 0)  # Alt up
        # 3. Try to bring it to front
        user32.SetForegroundWindow(original_hwnd)

        # 4. Disconnect threads
        user32.AttachThreadInput(this_thread, fg_thread, False)
        HWND_BROADCAST = 0xFFFF
        WM_SYSCOMMAND = 0x0112
        SC_MONITORPOWER = 0xF170
        MONITOR_OFF = 2

        #ctypes.windll.user32.PostMessageW(HWND_BROADCAST, WM_SYSCOMMAND, SC_MONITORPOWER, MONITOR_OFF)
        #os.system("\"\"C:\\Users\\teren\\Docs and Files\\github_repos\\C++\\other-stuff\\black\\x64\\Debug\\black.scr\"")
        print("Switched back.")
        keyboard.wait("Ctrl+B")
        print("Message")
        original_hwnd = user32.GetForegroundWindow()

        # Optional: get window title
        title = ctypes.create_string_buffer(256)
        user32.GetWindowTextA(original_hwnd, title, 256)
        print("Captured window title:", title.value.decode())
        original_hwnd = user32.GetForegroundWindow()

        # Optional: get window title
        title = ctypes.create_string_buffer(256)
        user32.GetWindowTextA(original_hwnd, title, 256)
    lst=frame

# # Step 3: Restore window if minimized
# SW_RESTORE = 9
# user32.ShowWindow(original_hwnd, SW_RESTORE)

# Step 4: Try to bring it back to the front
fg_thread = user32.GetWindowThreadProcessId(original_hwnd, None)
this_thread = kernel32.GetCurrentThreadId()

# 1. Restore the window if minimized

# 2. Temporarily allow your thread to interact with the foreground one
user32.AttachThreadInput(this_thread, fg_thread, True)
VK_MENU = 0x12
user32.keybd_event(VK_MENU, 0, 0, 0)  # Alt down
user32.keybd_event(VK_MENU, 0, 2, 0)  # Alt up
# 3. Try to bring it to front
user32.SetForegroundWindow(original_hwnd)

# 4. Disconnect threads
user32.AttachThreadInput(this_thread, fg_thread, False)
HWND_BROADCAST = 0xFFFF
WM_SYSCOMMAND = 0x0112
SC_MONITORPOWER = 0xF170
MONITOR_OFF = 2

#ctypes.windll.user32.PostMessageW(HWND_BROADCAST, WM_SYSCOMMAND, SC_MONITORPOWER, MONITOR_OFF)
#os.system("\"\"C:\\Users\\teren\\Docs and Files\\github_repos\\C++\\other-stuff\\black\\x64\\Debug\\black.scr\"")
print("Switched back.")
cv2.waitKey(10000)