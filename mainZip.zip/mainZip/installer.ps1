Invoke-WebRequest "https://github.com/winpython/winpython/releases/download/17.2.20250920final/WinPython64-3.14.0.1dot.zip" -OutFile portablePy.zip
Expand-Archive -Path portablePy.zip -DestinationPath python
echo "making env"
& "python\WPy64-31401\python\python.exe" -m venv env
echo activating venv
.\env\Scripts\Activate.ps1
python -m pip install --upgrade pip wheel setuptools
python -m pip install numpy==2.2.6 --only-binary=:all:
python -m pip install opencv-python keyboard filelock --only-binary=:all:
$Startup = [Environment]::GetFolderPath('Startup')
$CurrentDir = Get-Location
Set-Content -Path "$Startup\init-hider.bat" -Value "@echo off `n echo hello there, this window runs the hide script. If it ever closes, run `ncd $CurrentDir `n call .\env\Scripts\Activate.bat `n python besthide.py"
Copy-Item -Path "change_cam.bat" -Destination "..\"  -Force
Copy-Item -Path "manual_relaunch.bat" -Destination "..\"  -Force
Copy-Item -Path "uninstall.bat" -Destination "..\"  -Force
echo "Select a camera. Please press n for next camera and s to save camera. When the hider runs, you switch to the window you want to switch to and press control B twice. Then, if it's the first run since the script starting up, wait 10 seconds. Please DO NOT touch the mainZip folder."
python selector.py